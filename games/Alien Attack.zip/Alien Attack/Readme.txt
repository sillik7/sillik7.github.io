==================================
ALIEN ATTACK Created by Fiddlinboy
==================================

This game is freeware. You can copy it as much as you like and give it to as many people as you like.  Or don't like.

==============
ABOUT THE GAME
==============

The goal of the game is to destroy all the aliens before they touch the ground.  Or before they destroy you.  The only controls are left, right, and space to shoot.

During the game, you can press <P> to pause, <C> to enter cheat codes (you will be given four at the end of the game), and F12 to take a screenshot.

Each successful shot adds 100 points to your score.  Each unsuccessful shot docks 10 points.