"Angel&Satan" v1.02 - Original designed by Minoru Abe

This is the first of a series of sliding puzzle games i plan to recreate using the GameMaker software. It supports load and save of multiple games in progress, the ability to take back moves (or move forward), high score saving, and 'solution' files.

Solution files are generated (if you wish) after completing the puzzle. You can load them back, study your moves and then try to solve it in fewer moves! Or you can send them to someone else to see how you solved it.

The best solution for "Angel&Satan" is 74 moves and it is considered a medium difficulty puzzle. More info you can find using the 'Info' button in the game.

Since most sliding puzzles can be made using the same code of "Angel&Satan" i'll use it as a base for the rest of the puzzles. I'd like to know that everything works fine before continuing with the next puzzle so let me know if you find any bugs or if you have any suggestions/improvements to make.

Have fun!

Geoman
Contact: geomangr@yahoo.com