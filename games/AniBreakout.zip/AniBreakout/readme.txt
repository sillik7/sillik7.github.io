ANIbreakout README FILE
----------------------------------------------
Thanks for trying ANIbreakout!
I hope you'll enjoy using this game with your child or grandchild.
----------------------------------------------
CONTENTS
* System Requirements
* License
* Copyright
* Files included
* Installation
* Game Info
-----
MINIMUM SYSTEM REQUIREMENTS
* Windows 95
* Sound card (can be played without sound card)
-----
LICENSE
You are free to distribute the demo version of this game in any way so long as you do not charge for it beyond reasonable copying and distribution costs. It must also be distributed with all of it's original files in tact.
-----
COPYRIGHT
* The copyright for this game belongs to Kathi Phillips. She will retain all copyrights, trade secret rights, patents, trademarks and any other rights relating to the game. Except as expressly provided in the License above, you may not alter, modify, decompile, disassemble, reverse engineer, or create derivative works based on, the game. All rights not expressly granted are reserved. Any copy of the game which you are permitted to make under this Agreement must include all of the copyright and other notices appearing in the original copy of the game.
-----
FILES INCLUDED
* ANIbSW.exe
* game.gmr
* readme.txt (this file)
-----
INSTALLATION
To install the game on your computer, unzip it and place all three files in the same folder. To run the game, double click on the .exe file. By installing this game on your computer you acknowledge that computotgames nor myself nor any other website from which you obtained this software, shall be held responsible for any loss or damage caused by use, installation, or removal of this software.
To uninstall this game, simply delete the folder in which you placed the files.
-----
GAME INFO (The following can also be viewed while game is running by hitting F1)

GOAL
* ANIbreakout is based on the video arcade game of breakout. You have to get rid of all the objects by hitting them with the ball.

LEVELS
* This breakout game was designed for my two year old grandson. It is very simple and should be fairly easy. This version has 8 levels. During the game new animals and other surprises appear. The levels will get more difficult but are still fairly easy. Remember, it was designed for a two year old. The full version of the game has 25 levels.

TO START PLAY
* The ball will start moving a second or two after a room opens. This was done to allow the little ones an opportunity to get their paddle lined up under the ball.

PLAYING
* Move the paddle left and right using the mouse. You can change the direction of the ball by where you place the paddle as the ball descends. 

TO END PLAY
* Hit <esc>

TO SHOW GAME INFORMATION
* Hit <F1>

TO SWITCH BETWEEN FULL SCREEN AND WINDOW MODES
* Hit <F4>

HIGH SCORE
* When you get the high score window, type in the child's name then hit enter to return to the game. If all levels were completed, the child will be asked if they wish to play again. If yes is clicked, the game will restart at the first level. If all levels were not completed, the player will be asked to continue at the same level. If "yes" is clicked, the game restarts at the current level. If "no" is clicked, the game restarts at the first level.

DESIGN
* This game was designed to run on a 233 MHz computer (with a sound card) in full screen mode at a resolution of 800X600 pixels.  In window mode, on computers with other speeds, or at different resolutions, it may run very slow or extremely fast.

* It was also designed to be played with adult assistance as most children at this age will need some assistance with parts of the game. When I play this with my grandson, he sits on my lap and I guide his hand on the mouse as needed.

BALL SPEED
* The speed of the ball has been set slow because the game is designed for young children. However, for adults playing the game, the speed can be adjusted by using the left and right arrow keys. Each hit on the left arrow key will decrease the speed of the ball. Each hit on the right arrow key will increase the speed of the ball. Changing the speed will have to be done at the beginning of each new level. Wait for the ball to start moving before using the arrow keys, otherwise the ball drifts to the right before it starts moving.

KNOWN BUGS
* For some reason, on some computers, you may not be able to hear the sounds while playing in window mode. If you do not hear the sounds, try switching to full screen mode. Also, be sure that the window in which the game is running is the active window (you'll know it is the active window because the title bar across the top will be blue or whatever color your computer uses for the active window).

* Sometimes the ball may get caught in a loop. If the paddle is part of the loop, move the paddle. If the loop is with a moving block, wait it out. The block will move again. If it is for any other reason, hit F11 to restart the current level.

FULL VERSION
* To get the full version of ANIbreakout, send $10 (US) plus $2.50 (US) for shipping to Kathi Phillips PO Box 317799, Cincinnati, OH 45231-7799. I accept cash, check or money orders but am not responsible for cash sent via the postal service. Be sure to include your shipping address and the name of the game you are requesting. Allow 10-14 days for shipping. This is for continental US only. I will ship internationally but the shipping will be higher and may take longer. Please email me at poetkathi@computotgames.com with country to which you wish it shipped for international shipping rates. If your server permits attachments, save postage costs by including your email address in the order and requesting that it be sent via email.
* Full version of the game will be shipped on a 3 1/2 inch floppy disk.

COMMENTS OR BUGS
* Any comments you have or bugs you encounter can be sent to me at poetkathi@computotgames.com

* For a list of other computer games created for the under two crowd, email me at the same address or check my website at www.computotgames.com.

copyright 2001 Kathrine Rae Phillips
