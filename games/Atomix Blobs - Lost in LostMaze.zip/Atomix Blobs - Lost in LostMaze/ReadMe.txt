
Game Title:	ATOMIX BLOBS: LOST IN LOSTMAZE
Version:	1.2 (Full Version)
Category:	Puzzle/Arcade
Released Date: 	6th January 2001
Updated Date:   8th April 2001
Developed By:	Ron Marie Services
Contacting Us:  Email: ronnie@ronmarie.com
		Web site: http://www.ronmarie.com



============
INTRODUCTION
============
The Atomix Blobs were happy creatures who live happily in BLOBTOWN. One day, the evil
WACKO came and destroyed the entire town. 

Unknown to WACKO, there were still some Blobs who were 'out-of-town' during the 
catastrophe. Sad to find the entire BLOBTOWN destroyed by WACKO; the last 5 surviving
Blobs (Mandee, Cindee, Wandee, Zandee & Fandee) pledged to rebuild the town; and to 
rebuild the Blob generation, before they seek revenge on WACKO.  To do that, the Blobs
have to travel to the ARKADE WORLD to regain their atomix strength & power, and to 
collect all the materials to rebuild the BLOBTOWN again.


==============
THE GAME STORY
==============
In this game, Mandee the red Blob suddenly found himself lost in the LOSTMAZE Sector
of the ARKADE WORLD.  Mandee needs your help to guide him get out of the LOSTMAZE 
safely.  Simply guide Mandee towards the EXIT on each level. Be careful though, the
orange-colored tiles are very fragile and will collapse once Mandee steps on it. 

The EXIT gate will not open until all orange tiles are cleared on each level.  By the
way, don't ever let Mandee touch the blue-colored Atomix floor - it's deadly.  

You have only 5 chances to help Mandee!   Can you help? 


==========
GAME RULES 
==========
� Use the arrow keys (left, right, up, down) to guide Mandee move along the tiles.  

� Your mission ends when you have safely guided Mandee completed all 20 levels; or
  when you've failed in your mission (your 5 chances are gone).


Can you help the 5 Blobs regain their strength, power and rebuild the BLOBTOWN?   
Well, the only way is to get into the game now and let the experience begin!


========================
OTHER USEFUL INFORMATION
========================
1.  Press 'Q' at game level to return to MAIN MENU.  
    Press 'Q' at MAIN MENU to quit the game.

2.  Press "F4" to toggle between "FULL SCREEN mode" and "NORMAL WINDOW mode". 
    By default, this game runs in "FULL-SCREEN mode".  In "NORMAL Window mode", you
    can minimize or resize the game window, just like any other typical Windows
    application. 

3.  Press "F5" to save the current state of the game. 

4.  Press "F6" to load the previous saved state of the game. 


==================
SYSTEM REQUIREMENT
==================
* Multimedia PC with a Pentium 166 MHz or higher processor 
* Microsoft(tm) Windows(tm) 95 or Windows 98 operating system or later
* 32 MB of RAM
* 4 MB hard disk space required
* Sound Blaster� compatible sound card 
* Microsoft DirectX 6.0-compatible 
* SVGA video card capable of supporting 800 x 600 16-bit color display 


=======
HISTORY
=======
Version 0.9x    -  Dec 2000     -  Beta Testing
Version 1.0	-  1st Jan 2001	-  Released
Version 1.0a	-  6th Jan 2001 -  Pressing 'S' to start new game does not work. Fixed.
Version 1.2     -  8th April 2001 - Fixed minor bugs. Optimized code.


=========================
CREDITS & ACKNOWLEDGEMENT 
=========================
1.  This game was developed using the "GAME MAKER" engine, an intuitive drag-and-drop
    visual game development tool developed by Mark Overmars.  

    We highly recommend this tool if you wish to write their own game, even if you
    don't know anything about programming!

For more information on the "GAME MAKER" software, check Mark's GAME MAKER site at:
http://www.cs.uu.nl/~markov/kids/gmaker/index.html


=======================
DISCLAIMER & TRADEMARKS
=======================
THIS SOFTWARE AND THE ACCOMPANYING FILES ARE PROVIDED "AS IS" AND WITHOUT WARRANTIES
AS TO PERFORMANCE OR MERCHANTABILITY OR ANY OTHER WARRANTIES WHETHER EXPRESSED OR 
IMPLIED. 

RON MARIE SERVICES (HEREIN KNOWN AS "RMS") DISCAIMS ALL OTHER WARRANTIES, EITHER
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR PURPOSE, WITH RESPECT TO THE SOFTWARE, THE ACCOMPANYING
WRITTEN MATERIALS, AND ANY ACCOMPANYING HARDWARE.

NO LIABILITY FOR DAMAGES.  IN NO EVENT SHALL RMS OR ITS SUPPLIERS BE LIABLE FOR ANY
DAMAGES WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DIRECT DAMAGES, CONSEQUENTIAL 
DAMAGES AND OTHER PECUNIARY LOSS) ARISING OUT OF THE USE OF OR INABILITY TO USE THIS
RMS SOFTWARE PRODUCT, EVEN IF RMS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.


==========
COPYRIGHTS
==========
* The "ATOMIX BLOBS" game & it's Blob characters are developed and copyrighted by
  Ron Marie Services of Singapore.

* Any resemblance to the game, game characters, or music/effects are purely
  coincidental.

* "GAME MAKER" is copyrighted by Mark Overmars.

* All other product names & tradenames mentioned are copyrighted by their respective
  holders.


============
DISTRIBUTION
============
This is a FULL VERSION consisting of 20 exciting levels. This is the first of a series
of games we'll be developing under the "ATOMIX BLOBS" series. We've decided to release
this game as a "FREEWARE" as we hope you can enjoy playing the games just as much as
we do in designing them.

You may distribute this game on a PERSONAL basis, i.e., you are encouraged to pass it
to friends and associates so that they can enjoy the same experiences you had. 

For commercial CD bundling, please request an official permission from us; and/or 
availability of updated version or other game titles under the ATMOMIX BLOBS series.


===========================
OTHER GAMES DEVELOPED BY US
===========================
We also developer other types of games; with some of them receiving favorable response
and awards/accolades from recognised sites.  Always check our web site (listed above)
for more information on the games we've developed.


=============
CONTACTING US
=============
We welcome any suggestions, feedback or enquiry (commercial, business or personal) on
the games we've developed.  We're also available for customized games.

Feel free to contact us!


		==============================================
		GET INTO THE GAME NOW.. AND LET THE FUN BEGIN!
		==============================================


