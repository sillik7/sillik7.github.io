Bacteria 2.01
By Simon Donkers
www.simondonkers.com
webmaster@simondonkers.com

 --== Goal ==--

  Your goal is simple. Destroy red in as few moves as possible. When you 
  click a stone, it rotates clockwise. The stone that it points to is 
  converted. For each stone involved, any stone that is either pointed at 
  or is pointing to a green stone will be converted

  The rules are simple. The strategy required is not. 
  Good luck playing the game. 

 --== Controls ==--

  Left click on a stone to rotate the stone clockwise. 

 --== Additional controls ==--

  F3: toggle scaled full screen
  F4: toggle 640x480 full screen
  S:  toggle sounds
  V:  toggle voice
  M:  toggle music

 --== Usage policy of the source code ==--

  Bacteria 2 is provided as opensource for you to learn from. It is not allowed to use 
  the engine of Bacteria 2 for a commercial project under any circumstance. 
  Although I can't enforce this I would very much appreciate it if people are not going 
  to create a new Bacteria 3 game under there name. 

  Any new creation using a part of the code of this game must follow the following requirements:
  * Credit to Simon Donkers is at all time required with a link to www.simondonkers.com
  * It is not allowed to use the H Unit logo from within the loading animation within your 
    game under any circumstance. YOu can remove this by adjusting the sprite:
    sprites/menu-scree/sprite_credit_text Remove the first image from this animation. 
    The H Unit seal of quality has been granted to Bacteria 2 and to this game alone. Any creation 
    derived from this does not have the H Unit seal of quality unless given out by H Unit
  * It is not allowed to use the encryption mechanism used within this game within any other 
    creation without my prior personal permission
  * Any derived version needs to use a different game id. You can adjust your game id in:
    global game settings > loading. Having different versions with the same ID will cause problems
    when people try to connect with a multiplayer game as the game communication will not function
    properly.
  If you do make a game out of this engine I would be very interested to know about this, feel 
  free to send me an email at webmaster@simondonkers.com. :)

 --== CREDITS ==--
 
  Made by Simon Donkers
  Music by Neverest
  Highscore system by Eric Burgess (EricDB/Mr. Owl)
  Made with Game Maker by Mark Overmars - www.gamemaker.nl
  Inspired by Desinfect the core
  Special thanks to the members of the GMC and H Unit forum. 
  Also to (in random order) Wolverine, Mr. Hyun, tdgc, Tarik, S-Chuck, 
  t3mp3st, Viestituote, Jan-Maarten, all testers and you for playing this game. 

 --== FAQ ==--

  Q: Can I make a new game from the source?
  A: Read the section usage policy of the source above for information regarding this
  Q: I see a (grammar) error within this game or it's code. What should I do?
  A: Do nothing. I know about just about any error already. However for instance fixing 
     a typo within a resource name requires me to change all code referring to this resource
  Q: I am trying to modify your game but I don't understand how it works.
  A: I have published an article about the functionality of the AI on my website. 
  Q: I still need to unlock a few levels. What should I do?
  A: Info on all unlockables is at the button of this text file. 
     This info will spoil the fun of finding out self though. 
  Q: Within a multiplayer online game I keep gettting messages. 
     How do I send these messages myself?
  A: Type enter, type in your message and press enter again. 
     To play the evil laughter press numbers 1 to 4. 
  Q: When trying to start a multiplayer game it said 
     "No sessions available to join"
  A: Make sure you are not running from behind a router or are using ICS. 
     For info on solving this look at the requirements for multiplayer games.
     Also make sure you run the latest version of the game. You can download the 
     latest version at my site (www.simondonkers.tk)
  Q: Help, the game does not run?!
  A: Check if you meet the system requirements. Also make sure you have the 
     latest version for your video card drivers as well as DirectX. Also try 
     closing other programs to free up memory. 
  Q: How did you make this game?
  A: This game is made within Game Maker. A programming language by Mark OVermars. 
     www.gamemaker.nl

 --== Requirements ==--

  Windows 98 SE, NT, 2000, XP or later
  3D gfx card with at least 8mb of memory. Preferably 16mb or more. 
  DirectX 8.0 or later. Download at www.microsoft.com/directx
  A reasonably fast PC.

 --== Requirements for multiplayer online ==--

  An internet connection or a LAN connection with TCP-IP support
  Note that this game will very likely not work through a router or ICS. 
  More information at 
  http://support.microsoft.com/default.aspx?scid=http://support.microsoft.com:80/support/kb/articles/Q240/4/29.ASP&NoWebContent=1
  and http://forums.gamemaker.nl/index.php?showtopic=79904

 --== the fun part ==--

  Now that you have the engine of this game you can do some serious cheating. To 
  make this game easy for testing it will play any room you place within the 
  resource tree directly after room_splash. So if you want to give level 
  arcade_normal_3 a try without unlocking it, just drag it to there. (arcade_bonus_10 
  is very nice if I may say so myself)
  
 --== SPOILER ==--

  Please scroll down























 Requirements to unlock bonus levels:
  beat all levels of arcade green
  beat single player easy
  beat all levels of arcade yellow
  beat single player normal mode
  beat all levels of arcade red
  beat single player hard mode
  beat single player easy, normal and hard each 3 times
  beat the game 25x
  beat the game 50x
  beat all the above levels. (cool level)

 --== CHEATS ==--

  Please scroll down to read the cheats


























  type during arcade battle:
    inverse
      You will switch position with red. Progress will not be stored
    
    right-click
      Right click on a stone will allow for a counterclockwise rotation. 
      The AI will not perform this cheat. Only possible in arcade levels.
      Progress will not be stored.