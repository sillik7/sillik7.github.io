Bacteria 2.00
By Simon Donkers
www.simondonkers.tk
simondonkers@gmail.com

Goal

  Your goal is simple. Destroy red in as few moves as possible. When you 
  click a stone, it rotates clockwise. The stone that it points to is 
  converted. For each stone involved, any stone that is either pointed at 
  or is pointing to a green stone will be converted

  The rules are simple. The strategy required is not. 
  Good luck playing the game. 

Controlls:

  Left click on a stone to rotate the stone clockwise. 

Additional controlls:

  F3: toggle scaled full screen
  F4: toggle 640x480 full screen
  S:  toggle sounds
  V:  toggle voice
  M:  toggle music

CREDITS
 
  Made by Simon Donkers
  Music by Neverest
  Highscore system by Eric Burgess (EricDB/Mr. Owl)
  Made with Game Maker by Mark Overmars - www.gamemaker.nl
  Inspired by Desinfect the core
  Special thanks to the members of the GMC and H Unit forum. 
  Also to (in random order) Wolverine, Mr. Hyun, tdgc, Tarik, S-Chuck, 
  t3mp3st, Viestituote, Jan-Maarten, all testers and you for playing this game. 

FAQ

 Q: I still need to unlock a few levels. What should I do?
 A: Info on all unlockables is at the button of this text file. 
    This info will spoil the fun of finding out self though. 
 Q: Within a multiplayer online game I keep gettting messages. 
    How do I send these messages myself?
 A: Type enter, type in your message and press enter again. 
    To play the evil laughter press numbers 1 to 4. 
 Q: When trying to start a multiplayer game it said 
     "No sessions available to join"
 A: Make sure you are not running from behind a router or are using ICS. 
    For info on solving this look at the requirements for multiplayer games.
    Also make sure you run the latest version of the game. You can download the 
    latest version at my site (www.simondonkers.tk)
 Q: Help, the game does not run?!
 A: Check if you meet the system requirements. Also make sure you have the 
    latest version for your video card drivers as well as DirectX. Also try 
    closing other programs to free up memory. 
 Q: Can I get the source of this game?
 A: No, but if you want help on any specific part of programming a game, contact me. 
 Q: How did you make this game?
 A: This game is made within Game Maker. A programming language by Mark OVermars. 
    www.gamemaker.nl

Requirements:

  Windows 98 SE, NT, 2000, XP or later
  3D gfx card with at least 8mb of memory. Preferably 16mb or more. 
  DirectX 8.0 or later. Download at www.microsoft.com/directx
  A reasonably fast PC.

Requirements for multiplayer online:

  An internet connection
  Note that this game will very likely not work through a router or ICS. 
  More information at http://support.microsoft.com/default.aspx?scid=http://support.microsoft.com:80/support/kb/articles/Q240/4/29.ASP&NoWebContent=1
  and http://forums.gamemaker.nl/index.php?showtopic=79904

SPOILER

  Please scroll down























 Requirements to unlock bonus levels:
  beat all levels of arcade green
  beat single player easy
  beat all levels of arcade yellow
  beat single player normal mode
  beat all levels of arcade red
  beat single player hard mode
  beat single player easy, normal and hard each 3 times
  beat the game 25x
  beat the game 50x
  beat all the above levels. (cool level)

CHEATS

  Please scroll down to read the cheats


























  type during arcade battle:
    inverse
      You will switch position with red. Progress will not be stored
    
    right-click
      Right click on a stone will allow for a counterclockwise rotation. 
      The AI will not perform this cheat. Only possible in arcade levels.
      Progress will not be stored.