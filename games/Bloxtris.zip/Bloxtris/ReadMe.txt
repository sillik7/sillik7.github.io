
Game Title:	BLOXTRIS
Version:	1.2
Distribution:   Freeware 
Category:	Puzzle/Classic
Released Date: 	28th January 2001
Updated:        8th April 2001
Developed By:	Ron Marie Services, Singapore.
Contacting Us:  Email: ronnie@ronmarie.com
		Web site: http://www.ronmarie.com



============
INTRODUCTION
============
BLOXTRIS is our version of the classic 'falling block'-type of puzzle game, with a slight twist.  It's really simple to play.  Seven different shaped blocks fall down the game field one after the other.  The object of the game is to keep the blocks from piling up to the top of the game field.  To do this, you can move the blocks to the left and right, and rotate them as they fall.  If you can completely fill in one horizontal line, that line disappears and you get points.  If the blocks pile up to the top of the game field, that's the end of the game. 

BLOXTRIS is simple,  easy-to-understand and difficult to drag yourself away from!   This game is a test of your endurance where you must try to get the high score by  completing as many lines as possible.  The higher the LEVEL, the faster the  blocks fall down. During the course of the game, the LEVEL gradually increases and the game gets  increasingly harder.  When the block have reached the top of the game field,  that's the end of the game.

From Level 3 onwards, there's a new block known as 'swap block' which allows you to swap (exchange) the current falling block with this 'swap block'.  Only one block can be swapped per fall.   

Oh yes, be cautious of the falling bombs too - it can be destructive and... frustrating!

Enjoy 12 challenging levels of fun and excitement in this simple, easy-to-understand and yet addictive, mind-challenging 'finger-exercising' game! 


=============
GAME CONTROLS
=============
 <- (Left arrow)     -   Moves blocks to the left.
 -> (Right arrow)    -   Moves blocks to the right.
 \/ (Down arrow)     -   Makes the blocks fall down fast.
 /\ (Up arrow        -   Rotates the block.



==============
OTHER CONTROLS
==============
 F1      -    For Help - to access this help file.
 F4      -    Toggle between FULL-SCREEN and NORMAL WINDOW mode.
 F5      -    Saves the current game state (during game play)
 F6      -    Load the previous saved game state (during game play)
 ESC     -    Return to Main Menu (during game play)
 P       -    Pause the game (during game play). 
              Press SPACE BAR to restart the game from the moment it was stopped.
 Q       -    Quit this game (from Main Title Screen)
 R       -    Reset "Top 10 HighScore List" to default settings (from Main Title Screen)
 S       -    Swap a falling block with the block displayed on the 'Swap' location,
              shown on the bottom right of the game screen. You can only swap one
              block per fall. (available from Level 3 onwards)


===========
GAME SCREEN
===========
(Shows the SCORE, HIGH SCORE, LEVEL, LINES LEFT, NEXT, and FIELD display.)

SCORE       -  Shows the score you have earned by completing the lines.
HIGH SCORE  -  Shows the highest score earned previously. 
LEVEL       -  Shows the falling speed of the current block on screen.
LINES LEFT  -  Shows the total number of lines left (from 40 lines) to be completed since
               the start of the game.
NEXT        -  Shows the next block.
SWAP        -  Shows the SWAP block.
FIELD       -  This is where all the action is.


==============
Basic strategy
==============

* Align the blocks in a horizontal line making sure there are no gaps.

* If a complete line with no gaps is formed, that line will disappear from the screen.

* All the blocks remaining on the screen will fall down one line.

* Get a higher score by completing 2, 3 or 4 lines at once.  The deeper the pile of
  lines that is completed, the higher the score. As you get better at the game, you
  can complete two lines (a double), three lines (a triple) or four lines (a "BLOXTRIS") 
  with the drop of one block.  Doubles, triples, and BLOXTRISes will result in higher 
  score points.


==============
ABOUT BLOXTRIS
=============
BLOXTRIS was developed using the GameMaker engine. BLOXTRIS was written to test my skill in game authoring, and is adapted from a sample game code released by Mark Overmars for his GAMEMAKER software. 

BLOXTRIS is not TETRIS. PERIOD. It was *NOT* designed to be disguised, marketed, or behaved as one - it's just our own personal interpretation and tribute to the game we loved and played when it was first released.  

If  you really want to play TETRIS, go for the real stuff.


==================
SYSTEM REQUIREMENT
==================
* Multimedia PC with a Pentium 166 MHz or higher processor 
* Microsoft(tm)  Windows(tm)  95 or Windows 98 operating system or later
* 32 MB of RAM
* 4 MB hard disk space required
* Sound Blaster� compatible sound card 
* Microsoft DirectX 6.x compatible or higher
* SVGA video card capable of supporting 800 x 600 16-bit color display 


=======
HISTORY
=======
Version 1.0 -  28th Jan 2001    - Public Released
Version 1.2 -  8th April 2001    - Fixed minor bugs. Optimized code.


=========================
CREDITS & ACKNOWLEDGEMENT 
=========================
1.  Original Tetris concept, design and program by Alexey Pajitnov. 
    Tetris � by The Tetris Company. All rights reserved.

2.  BLOXTRIS was developed using the GameMaker engine, an easy-to-use game authoring 
    tool where you can write games easily and fast. For more information on the 
    "GAME MAKER" software, check Mark's GameMaker site at:

    http://www.cs.uu.nl/~markov/kids/gmaker/index.html



=======================
DISCLAIMER & TRADEMARKS
=======================
THIS SOFTWARE AND THE ACCOMPANYING FILES ARE PROVIDED "AS IS" AND WITHOUT WARRANTIES
AS TO PERFORMANCE OR MERCHANTABILITY OR ANY OTHER WARRANTIES WHETHER EXPRESSED OR 
IMPLIED. 

RON MARIE SERVICES (HEREIN KNOWN AS "RMS") DISCAIMS ALL OTHER WARRANTIES, EITHER
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF 
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, WITH RESPECT TO THE SOFTWARE, 
THE ACCOMPANYING WRITTEN MATERIALS, AND ANY ACCOMPANYING HARDWARE.

NO LIABILITY FOR DAMAGES.  IN NO EVENT SHALL RMS OR ITS SUPPLIERS BE LIABLE FOR ANY
DAMAGES WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DIRECT DAMAGES, CONSEQUENTIAL 
DAMAGES AND OTHER PECUNIARY LOSS) ARISING OUT OF THE USE OF OR INABILITY TO USE THIS
RMS SOFTWARE PRODUCT, EVEN IF RMS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
DAMAGES.



==========
COPYRIGHTS
==========
* BLOXTRIS and screen design copyrighted (C) by Ron Marie Services of Singapore.

* Any resemblance to the game, game characters, or music/effects are purely
  coincidental.

* "GAME MAKER" is copyrighted by Mark Overmars.

* All other product names & tradenames mentioned are copyrighted by their respective
  holders.


============
DISTRIBUTION
============
This is a FREEWARE version consisting of 12 levels.  You may distribute this game on 
a PERSONAL basis, i.e., you are encouraged to pass it to friends and associates so 
that they can enjoy the same experiences you had. 

For commercial CD bundling, please request an official permission from us; and/or 
availability of updated version or other game titles.



===========================
OTHER GAMES DEVELOPED BY US
===========================
We also developed other types of games; with some of them receiving favorable 
response and awards/accolades from recognised sites.  Always check our web site 
(listed above) for more information on the games we've developed.


=============
CONTACTING US
=============
We welcome any suggestions, feedback or enquiry (commercial, business or personal) on the games we've developed.  We're also looking for distributors who can help us distribute full version of our games to a wider market. If you're interested, please contact us with details on how you can help us.

Web site:  www.ronmarie.com
Email:     ronnie@ronmarie.com



		==============================================
		GET INTO THE GAMES NOW.. AND LET THE FUN BEGIN!
		==============================================


