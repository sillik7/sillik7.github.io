Chain Reaction Help.

Most of what you need to know is in the in-game instructions, but here's some needed info.

Object of the Game:
Simply change all the non-active particles (pinkish balls), into active ones
(green flashing balls). See the in-game instrustions for more complete details.

Controls:
"r" =restart level
"1-9" =change music
right click =de-select
left click = select
escape =return to main menu
"up" and "down" - navigate in the instructions


Saving:
Before you return to the main menu, you will be asked if you want to save the game.
If you do, you can them go back to the level you were on, by choosing "continue"
from the main menu.


Tips:
A few people had a problem figuring out how to start the reaction, 
so here's a little info: The start piece is the initial reaction which 
you will use to activate your nuclear pieces. Meaning that you must place 
a nuclear piece (radium or uranium) next to the start piece BEFORE clicking 
the start piece. Example, place a Radium "up" next to the start piece, click the
start piece, and the Radium "up" will have been activated, and hence, will 
begin to work. You then place other pieces in the path of the Radium "up" to 
activate them, thus, creating a "Chain Reaction".



If you find any bugs, please let me know. webmaster2x@yahoo.com


Credits:

Concept- Richard Gonzalez
Programming- Richard Gonzalez
Graphics- Richard Gonzalez & Lachlan McDonald  
Testing- Richard Gonzalez & Jason Gonzalez & Santiago Hernandez


Side Note:
Lachlan Mcdonald can do graphics (menus, logos, buttons ect) for your games as well. Simply
Visit his site at http://www28.brinkster.com/lazymoon/WORK/index.htm