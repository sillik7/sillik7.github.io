Columns QCG v.1.11
-----------
By : Jonathan Lam
Original game by:  SEGA

Minimum requirements
--------------------

- A modern PC running on Windows 95 or higher

- 640x480 screen resolution or higher 

- 16-bit colour (65536 colours) or higher

- DirectX 5 or higher

- 11 MB of free space

- a keyboard

Recommended
-----------

- 550 Mhz Pentium III machine or something equal to or better

- 800x600 screen resolution

- 24-bit colour (16.7 million colours) or higher

- DirectX 5 or higher

- 11 MB of free space

- a keyboard

- a sound card

Help Screen
-----------

Press F1 during the game to bring up the help screen.

Contents
--------

Columns QCG 1.11.exe - The game program.

cols.rcd - This file contains the top scores and top times for Columns QCG.  Don't tamper with 
the file if you don't know what you're doing, or you may lose you top scores/times and cause the 
game to malfunction.  If you want to reset the top scores/times because either you want to or you 
corrupted it, delete the file and the game will create a new one.

readme please.txt - this Readme document.

Visit the Quadricolour Games website at http://members.rogers.com/mstop4
If you have any comments, use the Feedback Form on the Quadricolour Games website.


