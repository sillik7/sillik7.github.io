
	Cooldog 1.0 First Release

	Bug :
	Sometimes cooldog crashes. I guess it's because of a 
	little memory leak. The timing of the crashes seem random.

	Cooldog comes as a Game maker file.
 	You need Game Maker 4.2a to run it.

	You can download Game Maker here:
	www.cs.ruu.nl/people/markov/gmaker

	If you have any questions, please mail to one of these
	email adresses :

	Antipasti@graffiti.net



	