*****************
* Cursed Undead *
***************** 

Made using Game Maker 6.0 (www.gamemaker.nl)
Music from: www.vgmusic.com
Sound from: www.flashkit.com/soundfx and www.grsites.com/sounds
Graphics, Design and Code by Nees Sonnemans


--------------------------------------
System Requirements:
--------------------------------------
- Microsoft Windows versions 98 SE or NT or 2000 or ME or XP.
- DirectX 8.0 or higher
- A videocard (8 MB at least) that supports 3D graphics 
- System must support a resolution of 1280x1024
- A mouse


--------------------------------------
Menu keys:
--------------------------------------
Use Up and Down to select menu options.
Use Enter or Space to execute menu options.
Use Escape to quit.


--------------------------------------
In Game Keys:
--------------------------------------
Use Up to move forward.
Use Down to move backward.
Use Left to turn 90 degrees to the left.
Use Right to turn 90 degrees to the Right.
Use Esc to save or quit


--------------------------------------
Mouse:
--------------------------------------
A mouse is required to be able to use the buttons at the right of the screen.
Simply click the button with the cursor to perform the action.
Buttons that require a mouse click are:
-Attack
-Berserk
-Heal
-Show Character
-Show Inventory
-Show Weaponry
There are also movement buttons that correspond to the arrow keys on the keyboard.


--------------------------------------
Cheats:
--------------------------------------
-Press F6 during the game to load the first level.
-Press F7 during the game to load the second level.
-Press F8 during the game to load the third level.
-Press F9 during the game to load the fourth level.
-Press F10 during the game to turn on invulnerability. 
-Press F11 during the game to turn on always-hit mode.
-Press F12 during the game to set the amount of bandages, armor pieces and magic shards to 90.


--------------------------------------
Contact:
--------------------------------------
for any questions related to Cursed undead mail to: nees_sonnemans@hotmail.com
Updates for this game will be available from: http://home.hccnet.nl/n.sonnemans




