				Dependence Day

		Produced for the Game Maker Competition 2001

				by Xception

			   This game is freeware.

Instructions

F1           Help
ESC          Exit Game
Cursor Keys  Move Spaceship
CTRL Key     Fire Weapons
P            Pause Game

  