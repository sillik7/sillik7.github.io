Dirty Drink Fighter             By J�rgen Levin Schj�dt-Hansen              22. October 2001 


In this folder you recieved:

Dirty Drink Fighter.exe - the program that runs Dirty Drink Fighter
data.gmr - The data of Dirty Drink Fighter
Screenshot of Dirty Drink Fighter.bmp - A screenshot of dirty Drink Fighter
Readme.txt - this file

TO START DIRTY DRINK FIGHTER:
1) To play Dirty Drink Fighter you will need the program winzip - http://www.winzip.com
2) Next unzip the files on your harddrive.
3) Open the file - Dirty Drink Fighter.exe
4) Now it asks for a file and then choose - data.gmr
and.....GO

DESCRIPTION:
Dirty Drink Fighter is a fight game. You can select 4 characters and you can both play single- and multiplayer. Also you can choose the sound you want to hear and also other available options.


If YOU want to create great games go to:

http://www.cs.uu.nl/people/markov/gmaker/index.html







This game was made with Game Maker

Thanks for playing :D