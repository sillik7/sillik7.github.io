                                    Dot Com
                                      by
                                  Zvika Israeli
                                     (2002)


In the wold of .com, there is only one way.
The fast way.
.com must do it clean and fast.


Dot Com is a fast Paced action game, in which you must think fast and move fast. 

In each level of the game, you must find the fastest path to collect all the glod bars.
.com must collect them before the timer reaches zero.

You should be careful from the falling gold balls, if they hit .com he goes to the start of the level.
If .com stand still and you press CTRL, he will rais his hands and bounce the gold ball.

If you can, try to collect the falling gold rings, they will give you extra time.


Keys:
Left and right arrow key to move
up key to climb ladders
ctrl to block the falling balls
F1 - help
F2 - stop music
F3 - start music
F5 - save game
F6 - load game

tips:
It is possible to finish all the levels ( dont give up quickly ).
The shortest way is not always the fastest way.
Climbing the ladders is ok, but falling down is faster, take advantage of the gravitation.
You can change the direction in air.
Try to be accurate when climbing the ladders between the stones.


more games in:

http://www.geocities.com/zvikaisraeli/free_classic_games.html

zvika.israeli@ness.com
zvikai@clalit.org.il

