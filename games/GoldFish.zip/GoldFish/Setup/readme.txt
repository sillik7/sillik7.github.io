                                    GoldFish Adventure 1.5

                                     by Zvika Israel 2001

Gold Fish is a simple Arcade Game for kids.
in each level you must find you way in the sea.

use the arrow keys and CTRL to fire

os: win9x, NT, ME, 2000, XP


