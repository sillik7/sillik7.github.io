                        LockOn 

                     iteration 002


Created by jph wacheski 
wacheski@hotmail.com


________________________CONTROL___________________________

use the ARROW keys to move about.
use the F key to lock onto the nearest target.
use the G key to fire a missile at current target.
use the H key to fire the forward gun.

press the SPACE bar to burst attack. lose one power level!
press the ENTER key to pause the game.
press the ESC key to leave the game. twice.
__________________________________________________________


Game Maker info.  
http://www.gamemaker.nl 

title music by Zug Island.  
more free mp3's at; 
http://www.subverseco.com/zugisland

iteration GAMES
http://iterationgames.com


(c)2003 jph wacheski / iteration GAMES