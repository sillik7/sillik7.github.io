Mario World 2K Readme.

Mario World 2K Controls:
Space = Jump
Z = Fly
Shift = Shoot
F1 = Save Game Part 1
F2 = Save Game Part 2
F3 = Save Game Part 3
F10 = Load Game Part 1
F11 = Load Game Part 2
F12 = Load Game Part 3

Game dowsn't work:

1. Be Sure You Have a 
Penium 1
180 MHz
16 Mb Ram

2. Still Dont Work
Download The File Again.

Weird Eye Software
