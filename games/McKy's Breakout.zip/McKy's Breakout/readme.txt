A freeware Breakout clone with many features such as MOD music,combos,etc. For a list of features,press F1 during the game.
For editor,press F5 in editor room.
This game was created with GameMaker.
Can be distributed.
If you want source code,contact me. You must have GameMaker installed.
To get GameMaker:http://www.cs.uu.nl/~markov/gmaker/

To start,open the file Mcky's Breakout.exe

System Requirements
*******************
266 MHz CPU
32 MB RAM
DirectX compatible 2D video card (2MB) 4MB is recommended.
Microsoft compatible mouse
Windows 95/98/ME/NT/2000
Sound card (Optional)

Tested On Celeron466
S3 Savage4 16MB
Geforce2 MX400 64MB

If the gameplay is still slow,try deleting the music files.

Credits
*******
I used some code from Mark Overmars's sample Breakout game.
Martin Rijks for the FMOD extension that enables MOD music.
The MOD songs composers.
The MOD archive website for all the MODS in this game.
