 __      __
|  \    /  |     0000     ___      ____      ___                   
|   \  /   |    0    0    \  \    /    \    /  /
| |\ \/ /| |    0    0     \  \  /  /\  \  /  /
| | \  / | |    0    0      \  \/  /  \  \/  /
| |  \/  | |    0    0       \    /    \    /
===      === o   0000  o      ====      ==== o

MEN OF WAR

***********************************************

this game was created with game maker by
Jonathan Tzeng(l33t h4xor)
:p

this is an updated version.
help file can be found within the game 
and a few minor errors were fixed.