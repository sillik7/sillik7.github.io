MONSTER FRENZY - Copyright Taurus Media - 2003
==============
(9/19/03)

STORY:

Zeebo, the one-eyed alien, crashed on a monster infested island and has no way to escape, as his ship is beyond repair. Luckily he has lots of fruit at his disposal (thanks to an enormous fruit tree), and an abandoned cabin for shelter, so he can survive for some time. The problem is, the seamonsters that inhabit the lagoon threaten to eat Zeebo if he doesn't help them satisfy their big appetites. The seamonsters are very picky eaters and only like certain fruits. Disappoint them, and Zeebo will be thrown into the lagoon from the resulting earthquake they will cause if angered.

Unfortunately the monsters are not only picky eaters and have big appetites, but they are also slave-drivers. They make poor Zeebo work round the clock from 6:00 in the morning to 12:00 midnight, until they are all well fed. 


OBJECTIVE:

Feed the monsters the appropriate colored fruit to keep the hunger bar (bottom of screen) from turning completely red. The bar will deplete faster everytime a monster eats the wrong colored fruit. It depletes even faster still if a rotten fruit is eaten. The basic objective is to survive until 12:00 midnight. You then get to wake up the next morning, same time same place, and do it all over again. (The monsters have no pity or remorse for you whatsoever) The challenge will be that the fruit will fall faster and faster with each passing day, making Zeebo work even harder. 

Poor Zeebo.

How long can YOU survive?



CONTROLS:

LEFT, RIGHT Arrow keys move Zeebo back and forth and navigate menus.
UP discards fruit.
DOWN drops fruit into water.
ESC prompts to quit game. (only during gameplay)


ENJOY MONSTER FRENZY!!! 

Lots of surprises await! :-)

==================================

Join the forums and participate in the Monster Frenzy survival competition.

http://www.taurusmedia.ca








