RED VS BLUE SHOOTER

This game is FREEWARE. You can give it to as many people as you like, 
but you must not modify it or charge any money for it.

To play it, just unzip the contents of the file to the folder you like 
and run redvsblue1.exe

system requirements:

- a modern Pentium PC
- Windows and DirectX
- a graphics card with 16-bit color 