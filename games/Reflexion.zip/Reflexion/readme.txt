=====================================================================
                 REFLEXION Copyright 2002 Juho Pohjonen
=====================================================================

This game is freeware. You can copy it as much as you like and give
it to as many people as you like. However, you must not charge any
money when you pass it on to someone else.

SYSTEM REQUIREMENTS

        REFLEXION requires:
        * a modern Pentium PC
        * Windows and DirectX
        * a fast graphics card with 16-bit color 
        * monitor refresh rate set to 100 Hz (IMPORTANT!)

TROUBLESHOOTING

	REFLEXION's gameplay is very sensitive to the refresh rate of
        your monitor.
        
        If "FPS WARNING!" appears the game may be too fast or too
	slow to be playable. Try to adjust the monitor refresh rate
	to 100 Hz. If the problem still remains, your computer may be
	too slow. In that case, buy a new computer!

KNOWN BUGS

        * Pressing Alt+TAB when playing is likely to crash the game
          sooner or later.