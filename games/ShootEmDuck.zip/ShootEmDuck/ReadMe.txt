
  ShootEmDuck (2002-03-30)

  Freeware for non-commercial use, 
  otherwise contact the author at
  floken@mail.telepac.pt

  Use at your own risk.

  All Rights Reserved


