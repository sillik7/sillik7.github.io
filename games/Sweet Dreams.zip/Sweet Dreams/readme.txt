
written with a registered copy of GM 5.1 - and uses some particle effects, so you will need a registered copy for everything to run correctly.

Enjoy!