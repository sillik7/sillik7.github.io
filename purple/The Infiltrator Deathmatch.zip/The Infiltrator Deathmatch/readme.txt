--------------------------
The Infiltrator Deathmatch
--------------------------

About
-----
A single player deathmatch game with bots. Made on a work-in-progress engine of The Infiltrator; it is a glimpse of things to come.

Performance
-----------
Slow computers can play this game but you will not be able to use as many bots or it will have slowdown. A few things to keep in mind for speed are the decals, and music. Turning all decals low and playing with no music increases the speed considerably.

Advanced Gameplay Info
----------------------
Not every bullet that appears to hit you or the enemy will take off damage; simply, some bullets miss. Shooting multiple times without pausing will cause less accuracy. Running or walking while shooting also affects accuracy.

If you want to make your bullets count, don't shoot as fast as possible, and stand or walk while shooting.

Depending which region you hit the enemy in will decide where the bullet hit him. For instance, if you hit the left or right side of his body with your bullet, you will either hit his shoulder or arm. The same applies for the middle section of the body.

Every gun has a certain rate of fire, reload, damage attributes, and ammo type. Choosing the best combination of gun(s) that suit you can be the difference between life or death.

Every time you get shot, or shoot someone else, they will bleed. For every time shot, a new wound will open, causing bleeding more frequently and a greater loss of heatlh per blood drop. There is no way to stop the bleeding.

If you or an enemy bleeds to death, the last person who shot them will be awarded the kill.

Modes
-----
Deathmatch- Kill anything that moves, first to reach the set limit wins.

Team Deathmatch- Kill anything that is not your colour. The first team to reach the set limit wins.

Capture the Case- Capture the other teams case(s) and score it by touching one of your cases. The more cases you carry, the slower you will move.

Controls & Music
----------------
Every button is customizable, except the quit key (Escape), the screen mode toggle button (F4), and the music keys.

Pressing 1 or 2 will play the song you specified under each number, and pressing 0 will stop the current song playing.

Misc
----
If you want the source for this game, you won't get it. Don't even bother e-mailing us, we will just say no.

Contact
-------
You can e-mail us at: gzsoft@shaw.ca
You can check our website out here: http://members.shaw.ca/gzsoft