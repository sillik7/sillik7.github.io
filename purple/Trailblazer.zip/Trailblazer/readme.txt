      				 Trailblazer
				  Copyright 
				    2002 
				  Xception

Controls:

Keyboard: 
cursor keys left, right move ball left, right
cursor key up: accelerate
cursor key down: brake
CTRl to jump

or use joystick 1

The Jumpbar indicates your jump power.
